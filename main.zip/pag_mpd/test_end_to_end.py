#!/usr/bin/env python3
import os
import sys
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pattern_aware_graph import PatternAwareGraphEncoder
from meta_adaptive_prompts import SparseRouting, PromptNetwork, LowRankAdapters
from uncertainty_aware_transfer import (
    CrossModalConsistency,
    TeacherModel,
    UncertaintyDistillation,
)

def main():
    torch.manual_seed(42)
    B = 4
    d = 768
    d_u = 128
    K = 6
    S = 2
    C = 5
    modality_names = ["text", "image"]

    config = {
        'hidden_size': d,
        'num_modalities': len(modality_names),
        'modality_names': modality_names,
        'statistical_embed_dim': d_u,
        'drop_rate': 0.0,
        # routing
        'num_paths': K,
        'top_s': S,
        'gumbel_tau': 1.0,
        # prompt/adapters
        'adapter_rank': 8,
        'adapter_cond_dim': d_u,
        'prompt_len': 4,
        'prompt_cond_dim': d + d_u,
        'prompt_hidden': 256,
        # fusion+KD
        'fusion_heads': 4,
        'contrastive_tau': 0.07,
        'contrastive_proj': 256,
        'num_classes': C,
        'lambda_kd': 1.0,
        'lambda_lap': 0.1,
        'lambda_con': 0.1,
    }

    # 1) Graph encoder inputs: per-modality embeddings (pretend already encoded) and missing mask r_i
    text_embeds = torch.randn(B, d)
    image_embeds = torch.randn(B, d)
    missing_mask = torch.tensor([[1,1],[1,0],[0,1],[0,0]])

    graph = PatternAwareGraphEncoder(config)
    ge = graph.encode_with_details(text_embeds, image_embeds, missing_mask)
    routing_context = ge['routing_context']              # (B, d_c)
    z_tilde = ge['updated_modality_embeddings']          # dict m->(B,d)
    u_i = ge['statistical_embedding']                    # (B, d_u)
    A_norm = ge['normalized_adjacency']                  # (M, M)

    # 2) Sparse routing + prompts + adapters
    router = SparseRouting({**config, 'routing_in_dim': graph.get_routing_context_dim()})
    r_out = router(routing_context, training=True)
    alpha = r_out['weights']                             # (B, K)

    adapters = LowRankAdapters(config)
    adapters_k = adapters(u_i)                           # dict[path][mod]{U,V}

    pnet = PromptNetwork(config)
    prompts_k = pnet(z_tilde, u_i)                       # dict[path][mod]->(B,Tp,d)

    # per-path hat{z}
    Kval = alpha.shape[1]
    hat_per_k = []
    for k in range(Kval):
        hat_k = pnet.combine_with_adapter(
            z_tilde,
            prompts_k[str(k)],
            adapters_k[str(k)],
            LowRankAdapters.apply_adapter,
            pnet.prompt_attention,
        )
        hat_per_k.append(hat_k)

    # aggregate \bar{z} and p_final
    bar_z = {}
    p_final = pnet.aggregate_prompts(prompts_k, alpha, modality_names)
    for m in modality_names:
        z_stack = torch.stack([hat_per_k[k][m] for k in range(Kval)], dim=1)  # (B,K,d)
        bar_z[m] = (z_stack * alpha.unsqueeze(-1)).sum(dim=1)

    # 3) Fusion + teacher/student KD + consistency losses
    cmc = CrossModalConsistency(config)
    modality_feats = {m: bar_z[m] + p_final[m] for m in modality_names}
    fused = cmc.fuse(modality_feats)

    teacher = TeacherModel(config)
    alpha_t = teacher(modality_feats)['alpha']

    dirichlet_head = torch.nn.Linear(d, C)
    alpha_s = torch.nn.functional.softplus(dirichlet_head(fused)) + 1.0

    kd = UncertaintyDistillation(config)
    kd_out = kd(alpha_t, alpha_s)

    lap = cmc.laplacian_loss(modality_feats, A_norm) * config['lambda_lap']
    con = cmc.contrastive_loss(modality_feats) * config['lambda_con']

    # classification (fake labels)
    labels = torch.randint(0, C, (B,))
    logits = torch.nn.Linear(d, C)(fused)
    cls = torch.nn.functional.cross_entropy(logits, labels)

    total = cls + kd_out['loss_kd_weighted'] + lap + con + (-r_out['loss_peak']) * 0 + r_out['loss_div'] * 0

    print('✓ Shapes:', {
        'routing_context': tuple(routing_context.shape),
        'fused': tuple(fused.shape),
        'alpha_t': tuple(alpha_t.shape),
        'alpha_s': tuple(alpha_s.shape),
    })
    print('✓ Losses:', {
        'cls': float(cls),
        'kd_weighted': float(kd_out['loss_kd_weighted']),
        'lap': float(lap),
        'con': float(con),
        'peak': float(r_out['loss_peak']),
        'div': float(r_out['loss_div']),
        'total': float(total),
    })
    print('\nEnd-to-end minimal forward passed.')


if __name__ == '__main__':
    main()
