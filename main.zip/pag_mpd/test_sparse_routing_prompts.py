#!/usr/bin/env python3
import os
import sys
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from meta_adaptive_prompts import SparseRouting, LowRankAdapters, PromptNetwork


def main():
    B = 4
    d = 768
    d_u = 128
    K = 6
    S = 2
    T_p = 4
    modality_names = ["text", "image"]

    config = {
        'hidden_size': d,
        'num_paths': K,
        'top_s': S,
        'drop_rate': 0.0,
        'routing_in_dim': d * len(modality_names) + d_u,
        'routing_hidden': 256,
        'adapter_rank': 8,
        'adapter_cond_dim': d_u,  # condition on u_i for adapters
        'prompt_len': T_p,
        'prompt_cond_dim': d + d_u,  # concat z and u
        'prompt_hidden': 256,
        'modality_names': modality_names,
    }

    # Fake routing context from module-1
    routing_context = torch.randn(B, config['routing_in_dim'])

    # 1) Sparse routing
    router = SparseRouting(config)
    out = router(routing_context, training=True)
    weights = out['weights']
    assert weights.shape == (B, K)
    print('✓ routing weights:', weights.shape, 'loss_peak:', float(out['loss_peak']), 'loss_div:', float(out['loss_div']))

    # Prepare per-modality embeddings and statistical embedding
    modality_embeddings = {m: torch.randn(B, d) for m in modality_names}
    u_i = torch.randn(B, d_u)

    # 2) Low-rank adapters
    adapters = LowRankAdapters(config)
    adapters_params = adapters(u_i)  # dict[path][modality]{U,V}
    # Apply adapters for a given path selection (use soft weights to mix later)

    # 3) Prompt network
    prompt_net = PromptNetwork(config)
    prompts_per_path = prompt_net(modality_embeddings, u_i)  # dict[path][modality] -> (B, T_p, d)

    # Aggregate prompts with weights
    final_prompts = PromptNetwork.aggregate_prompts(prompts_per_path, weights, modality_names)
    for m in modality_names:
        assert final_prompts[m].shape == (B, d)
    print('✓ aggregated prompts per modality:', {m: v.shape for m, v in final_prompts.items()})

    print('\nAll sparse routing + prompts tests passed.')


if __name__ == '__main__':
    main()


