#!/usr/bin/env python3
import os
import sys
import torch

# ensure project root is on path
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from pag_mpd.core import PAGMPDModel


def main():
    torch.manual_seed(0)
    B = 4
    L = 12
    d = 768
    C = 5

    config = {
        'mock_backbone': True,
        'vocab_size': 30522,
        'hidden_size': d,
        'num_layers': 2,
        'num_heads': 8,
        'mlp_ratio': 4,
        'max_text_len': L,
        'drop_rate': 0.0,
        'max_image_len': 10,
        'num_modalities': 2,
        'modality_names': ['text','image'],
        'statistical_embed_dim': 128,
        'num_paths': 4,
        'top_s': 2,
        'gumbel_tau': 1.0,
        'adapter_rank': 8,
        'adapter_cond_dim': 128,
        'prompt_len': 4,
        'prompt_cond_dim': d + 128,
        'prompt_hidden': 256,
        'fusion_heads': 4,
        'contrastive_tau': 0.07,
        'contrastive_proj': 256,
        'num_classes': C,
        'lambda_kd': 1.0,
        'lambda_lap': 0.1,
        'lambda_con': 0.1,
        'loss_names': {'hatememes':0,'food101':0,'mmimdb':0},
        'load_path': '',
    }

    model = PAGMPDModel(config)

    # build synthetic batch
    text_ids = torch.randint(0, config['vocab_size'], (B, L))
    text_labels = torch.zeros(B, L, dtype=torch.long)
    text_masks = torch.ones(B, L, dtype=torch.long)
    images = torch.randn(B, 3, 224, 224)
    missing_type = torch.tensor([[1,1],[1,0],[0,1],[0,0]], dtype=torch.long)
    labels = torch.randint(0, C, (B,))

    batch = {
        'text_ids': text_ids,
        'text_labels': text_labels,
        'text_masks': text_masks,
        'image': (images,),
        'missing_type': missing_type,
        'labels': labels,
    }

    out = model.infer(batch)
    loss_items = {k: float(v) for k,v in out.items() if isinstance(v, torch.Tensor) and k.startswith('loss/')}
    print('✓ loss items:', loss_items)
    print('✓ fused_feats:', tuple(out['fused_feats'].shape))
    print('✓ logits:', tuple(out['logits'].shape))

    # simulate training_step aggregation
    total = sum([v for k,v in out.items() if isinstance(v, torch.Tensor) and 'loss' in k])
    print('✓ total loss (sum of loss*):', float(total))


if __name__ == '__main__':
    main()
