"""
PAG-MPD Main Model

This module implements the main PAG-MPD model that integrates all three components:
1. Pattern-aware graph encoding
2. Meta-adaptive prompt generation  
3. Uncertainty-aware knowledge transfer
"""

import torch
import torch.nn as nn
try:
    import pytorch_lightning as pl
    _BaseLM = pl.LightningModule
except Exception:
    # Optional shim so that module can be imported without PL installed (for tests)
    class _LightningModuleShim(nn.Module):
        def __init__(self):
            super().__init__()
        def save_hyperparameters(self):
            pass
    pl = None
    _BaseLM = _LightningModuleShim
try:
    from transformers.models.bert.modeling_bert import BertConfig, BertEmbeddings  # type: ignore
except Exception:
    BertConfig, BertEmbeddings = None, None

from ..pattern_aware_graph import PatternAwareGraphEncoder
from ..meta_adaptive_prompts import SparseRouting, PromptNetwork, LowRankAdapters
from ..uncertainty_aware_transfer import CrossModalConsistency, TeacherModel, UncertaintyDistillation

# heads / objectives are heavy; make optional
try:
    from ..modules import heads, objectives  # type: ignore
except Exception:
    heads, objectives = None, None

# Vision backbone import (optional)
try:
    from ..modules.vision_transformer_prompts import VisionTransformer  # type: ignore
except Exception:
    VisionTransformer = None

# utils may be heavy; make optional
try:
    from ..utils import vilt_utils  # type: ignore
except Exception:
    class _VU:
        @staticmethod
        def set_metrics(_):
            pass
        @staticmethod
        def set_schedule(_):
            return None
        @staticmethod
        def epoch_wrapup(_):
            pass
        @staticmethod
        def set_task(_):
            pass
    vilt_utils = _VU()


class PAGMPDModel(_BaseLM):
    """
    Pattern-Aware Graph Routing and Meta-Adaptive Prompt Distillation Model
    
    This model integrates three key components:
    1. Pattern-aware graph encoding for handling missing modalities
    2. Meta-adaptive prompt generation for robust multimodal fusion
    3. Uncertainty-aware knowledge transfer for stable supervision
    """
    
    def __init__(self, config):
        super().__init__()
        # In non-PL mode, emulate hparams
        try:
            self.save_hyperparameters()
        except Exception:
            pass
        if not hasattr(self, 'hparams') or not hasattr(self, 'hparams') or not hasattr(getattr(self, 'hparams'), 'config'):
            class _HP: pass
            self.hparams = _HP()
            self.hparams.config = dict(config)
        
        # Config flags
        self.mock_backbone = config.get("mock_backbone", False)

        # Initialize text embeddings
        if not self.mock_backbone and BertEmbeddings is not None:
            bert_config = BertConfig(
                vocab_size=config["vocab_size"],
                hidden_size=config["hidden_size"],
                num_hidden_layers=config["num_layers"],
                num_attention_heads=config["num_heads"],
                intermediate_size=config["hidden_size"] * config["mlp_ratio"],
                max_position_embeddings=config["max_text_len"],
                hidden_dropout_prob=config["drop_rate"],
                attention_probs_dropout_prob=config["drop_rate"],
            )
            self.text_embeddings = BertEmbeddings(bert_config)
            if objectives is not None:
                self.text_embeddings.apply(objectives.init_weights)
        else:
            self.text_embeddings = nn.Embedding(config["vocab_size"], config["hidden_size"])
        
        self.token_type_embeddings = nn.Embedding(2, config["hidden_size"])
        if objectives is not None:
            self.token_type_embeddings.apply(objectives.init_weights)
        
        # Initialize Vision Transformer or mock
        if self.mock_backbone or VisionTransformer is None:
            dim = config["hidden_size"]
            class _MockBlock(nn.Module):
                def __init__(self, d):
                    super().__init__()
                    self.ffn = nn.Sequential(nn.LayerNorm(d), nn.Linear(d, d))
                def forward(self, x, mask=None):
                    return self.ffn(x), None
            class _MockViT(nn.Module):
                def __init__(self, d, num_blocks=2):
                    super().__init__()
                    self.blocks = nn.ModuleList([_MockBlock(d) for _ in range(num_blocks)])
                    self.norm = nn.LayerNorm(d)
                def visual_embed(self, img, max_image_len=None, mask_it=False):
                    B = img.shape[0]
                    T = 10
                    d = dim
                    embeds = torch.randn(B, T, d, device=img.device)
                    masks = torch.ones(B, T, dtype=torch.long, device=img.device)
                    return embeds, masks, None, None
            self.transformer = _MockViT(dim)
        else:
            if self.hparams.config["load_path"] == "":
                self.transformer = VisionTransformer(pretrained=True, config=self.hparams.config)
            else:
                self.transformer = VisionTransformer(pretrained=False, config=self.hparams.config)
        
        # Initialize PAG-MPD components
        self.pattern_aware_graph = PatternAwareGraphEncoder(config)
        # prepare routing input dim d_c
        routing_in_dim = self.pattern_aware_graph.get_routing_context_dim()
        self.hparams.config["routing_in_dim"] = routing_in_dim
        # infer prompt/adapter cond dims if missing
        if "prompt_cond_dim" not in self.hparams.config:
            self.hparams.config["prompt_cond_dim"] = self.hparams.config["hidden_size"] + self.hparams.config.get("statistical_embed_dim", 128)
        if "adapter_cond_dim" not in self.hparams.config:
            self.hparams.config["adapter_cond_dim"] = self.hparams.config.get("statistical_embed_dim", 128)
        # meta-adaptive prompt generation stack
        self.sparse_routing = SparseRouting(self.hparams.config)
        self.prompt_network = PromptNetwork(self.hparams.config)
        self.low_rank_adapters = LowRankAdapters(self.hparams.config)
        # fusion and consistency (MHAttn + optional losses)
        self.consistency = CrossModalConsistency(self.hparams.config)
        # teacher & KD
        self.teacher_model = TeacherModel(self.hparams.config)
        self.uncertainty_distillation = UncertaintyDistillation(self.hparams.config)
        # student Dirichlet head from fused feature
        num_classes = self.hparams.config.get("num_classes", self.hparams.config.get("hatememes_class_num", 2))
        self.dirichlet_head = nn.Linear(self.hparams.config["hidden_size"], num_classes)
        # classification head for cross-entropy
        self.classifier_head = nn.Linear(self.hparams.config["hidden_size"], num_classes)
        
        # Initialize classification heads
        if heads is not None and hasattr(heads, "Pooler"):
            self.pooler = heads.Pooler(config["hidden_size"])
            if objectives is not None:
                self.pooler.apply(objectives.init_weights)
        else:
            class _Pooler(nn.Module):
                def __init__(self, d):
                    super().__init__()
                    self.norm = nn.LayerNorm(d)
                def forward(self, x):
                    return self.norm(x[:, :1])
            self.pooler = _Pooler(config["hidden_size"])
        
        # Task-specific classifiers
        self._init_classifiers(config)
        
        # Load pre-trained weights if specified
        if self.hparams.config["load_path"] != "":
            self._load_pretrained_weights()
        
        # Set up metrics and tasks
        vilt_utils.set_metrics(self)
        self.current_tasks = list()
        self.records = {}

        # Optionally freeze backbone (transformer and text/token embeddings)
        if self.hparams.config.get("fix_model", True):
            for p in self.transformer.parameters():
                p.requires_grad = False
            for p in self.text_embeddings.parameters():
                p.requires_grad = False
            for p in self.token_type_embeddings.parameters():
                p.requires_grad = False
    
    def _init_classifiers(self, config):
        """Initialize task-specific classifiers"""
        hs = config["hidden_size"]
        
        if config["loss_names"]["hatememes"] > 0:
            cls_num = config["hatememes_class_num"]
            self.hatememes_classifier = nn.Sequential(
                nn.Linear(hs, hs * 2),
                nn.LayerNorm(hs * 2),
                nn.GELU(),
                nn.Linear(hs * 2, cls_num),
            )
            self.hatememes_classifier.apply(objectives.init_weights)
            
        if config["loss_names"]["food101"] > 0:
            cls_num = config["food101_class_num"]
            self.food101_classifier = nn.Sequential(
                nn.Linear(hs, hs * 2),
                nn.LayerNorm(hs * 2),
                nn.GELU(),
                nn.Linear(hs * 2, cls_num),
            )
            self.food101_classifier.apply(objectives.init_weights)
            
        if config["loss_names"]["mmimdb"] > 0:
            cls_num = config["mmimdb_class_num"]
            self.mmimdb_classifier = nn.Sequential(
                nn.Linear(hs, hs * 2),
                nn.LayerNorm(hs * 2),
                nn.GELU(),
                nn.Linear(hs * 2, cls_num),
            )
            self.mmimdb_classifier.apply(objectives.init_weights)
    
    def _load_pretrained_weights(self):
        """Load pre-trained weights"""
        ckpt = torch.load(self.hparams.config["load_path"], map_location="cpu")
        state_dict = ckpt["state_dict"]
        
        # Handle position embedding interpolation for different max_text_len
        if self.hparams.config["max_text_len"] != 40:
            state_dict['text_embeddings.position_ids'] = torch.Tensor(
                range(self.hparams.config["max_text_len"])
            ).long().view(1, -1)
            pos_emb = state_dict['text_embeddings.position_embeddings.weight']
            pos_emb = torch.nn.functional.interpolate(
                pos_emb.view(1, 1, 40, 768), 
                size=(self.hparams.config["max_text_len"], 768), 
                mode='bilinear'
            ).squeeze()
            state_dict['text_embeddings.position_embeddings.weight'] = pos_emb
        
        self.load_state_dict(state_dict, strict=False)
    
    def forward(self, batch):
        """
        Forward pass through PAG-MPD model
        
        Args:
            batch: Input batch containing text, image, and missing modality information
            
        Returns:
            dict: Model outputs including predictions and losses
        """
        ret = dict()
        
        if len(self.current_tasks) == 0:
            ret.update(self.infer(batch))
            return ret
        
        # Compute task-specific losses
        if "hatememes" in self.current_tasks:
            ret.update(objectives.compute_hatememes(self, batch))
            
        if "mmimdb" in self.current_tasks:
            ret.update(objectives.compute_mmimdb(self, batch))
            
        if "food101" in self.current_tasks:
            ret.update(objectives.compute_food101(self, batch))
        
        return ret
    
    def infer(self, batch, mask_text=False, mask_image=False, image_token_type_idx=1):
        """
        Inference through PAG-MPD model
        
        Args:
            batch: Input batch
            mask_text: Whether to mask text tokens
            mask_image: Whether to mask image patches
            image_token_type_idx: Image token type index
            
        Returns:
            dict: Inference results
        """
        # Extract input data
        if f"image_{image_token_type_idx - 1}" in batch:
            imgkey = f"image_{image_token_type_idx - 1}"
        else:
            imgkey = "image"
        
        do_mlm = "_mlm" if mask_text else ""
        text_ids = batch[f"text_ids{do_mlm}"]
        text_labels = batch[f"text_labels{do_mlm}"]
        text_masks = batch[f"text_masks"]
        text_embeds = self.text_embeddings(text_ids)
        img = batch[imgkey][0]
        
        # Get image embeddings
        image_embeds, image_masks, patch_index, image_labels = self.transformer.visual_embed(
            img,
            max_image_len=self.hparams.config["max_image_len"],
            mask_it=mask_image,
        )
        
        # Add token type embeddings
        text_embeds = text_embeds + self.token_type_embeddings(torch.zeros_like(text_masks))
        image_embeds = image_embeds + self.token_type_embeddings(
            torch.full_like(image_masks, image_token_type_idx)
        )
        
        # Pattern-aware graph encoding with details
        missing_patterns = batch["missing_type"]  # Binary mask r_i
        # Pool token-level embeddings to modality-level vectors for graph encoder
        text_pooled = text_embeds.mean(dim=1)
        image_pooled = image_embeds.mean(dim=1)
        # Optional audio branch (COVAREP) projected to 128 then to hidden if needed
        extra = None
        if self.hparams.config.get("use_audio", False) and "audio_feats" in batch:
            audio = batch["audio_feats"]  # (B, D_a)
            # expect D_a == 128; project to hidden if needed for unified d
            D_a = audio.shape[-1]
            if D_a != self.hparams.config.get("statistical_embed_dim", 128):
                # ensure numerical compatibility, simple linear proj
                proj = nn.Linear(D_a, self.hparams.config.get("statistical_embed_dim", 128)).to(audio.device)
                audio = proj(audio)
            # then map to hidden size for fusion path if hidden != d_u
            if self.hparams.config["hidden_size"] != self.hparams.config.get("statistical_embed_dim", 128):
                proj_h = nn.Linear(self.hparams.config.get("statistical_embed_dim", 128), self.hparams.config["hidden_size"]).to(audio.device)
                audio_h = proj_h(audio)
            else:
                audio_h = audio
            extra = {"audio": audio_h}

        ge_out = self.pattern_aware_graph.encode_with_details(
            text_pooled, image_pooled, missing_patterns, extra_modalities=extra
        )
        routing_context = ge_out['routing_context']
        updated_modality_embeddings = ge_out['updated_modality_embeddings']  # dict name->(B,d)
        statistical_embedding = ge_out['statistical_embedding']
        normalized_adjacency = ge_out['normalized_adjacency']

        # Differentiable sparse routing
        route_out = self.sparse_routing(routing_context, training=self.training)
        routing_weights = route_out['weights']  # (B,K)
        loss_peak = route_out['loss_peak']
        loss_div = route_out['loss_div']

        # Generate per-path adapters (condition on u_i) and prompts (condition on [z^m, u_i])
        adapters_per_path = self.low_rank_adapters(statistical_embedding)  # dict[path][mod]{U,V}
        prompts_per_path = self.prompt_network(updated_modality_embeddings, statistical_embedding)

        # For each path k, compute \hat{z}^{m,k} = Adapter + PromptAttn
        # then aggregate across paths with routing weights to get \bar{z}^m and p_final^m
        K = routing_weights.shape[1]
        modality_names = list(updated_modality_embeddings.keys())
        B = routing_context.shape[0]
        d = updated_modality_embeddings[modality_names[0]].shape[-1]

        # collect per-path hat z
        hat_z_per_path = []  # list length K of dict modality->(B,d)
        for k in range(K):
            k_key = str(k)
            hat_k = self.prompt_network.combine_with_adapter(
                updated_modality_embeddings,
                prompts_per_path[k_key],
                adapters_per_path[k_key],
                self.low_rank_adapters.apply_adapter,
                self.prompt_network.prompt_attention,
            )
            hat_z_per_path.append(hat_k)

        # aggregate bar_z and p_final
        bar_z = {}
        p_final = self.prompt_network.aggregate_prompts(prompts_per_path, routing_weights, modality_names)
        for m in modality_names:
            # stack (B,K,d)
            z_stack = torch.stack([hat_z_per_path[k][m] for k in range(K)], dim=1)
            w = routing_weights.unsqueeze(-1)  # (B,K,1)
            bar_z[m] = (z_stack * w).sum(dim=1)
        
        # Apply prompts and process through transformer
        # This is a simplified version - the actual implementation would be more complex
        co_masks = torch.cat([text_masks, image_masks], dim=1)
        co_embeds = torch.cat([text_embeds, image_embeds], dim=1)
        
        # Process through transformer blocks (kept as original backbone forward)
        x = co_embeds.detach()
        for i, blk in enumerate(self.transformer.blocks):
            x, _attn = blk(x, mask=co_masks)
        
        x = self.transformer.norm(x)
        
        # Extract features
        text_feats = x[:, :text_embeds.shape[1]]
        image_feats = x[:, text_embeds.shape[1]:]
        cls_feats = self.pooler(x[:, :1])
        
        # PAG-MPD: build modality features for fusion: z_bar + p_final
        modality_feats = {m: bar_z[m] + p_final[m] for m in modality_names}
        fused_feats = self.consistency.fuse(modality_feats)

        # Dirichlet student and teacher, KD and consistency losses
        tea_out = self.teacher_model(modality_feats)
        alpha_t = tea_out["alpha"]
        stu_logits = self.dirichlet_head(fused_feats)
        alpha_s = torch.nn.functional.softplus(stu_logits) + 1.0
        kd_out = self.uncertainty_distillation(alpha_t, alpha_s)

        lambda_kd = self.hparams.config.get("lambda_kd", 1.0)
        lambda_lap = self.hparams.config.get("lambda_lap", 0.0)
        lambda_con = self.hparams.config.get("lambda_con", 0.0)
        lambda_peak = self.hparams.config.get("lambda_peak", 0.0)
        lambda_div = self.hparams.config.get("lambda_div", 0.0)

        lap_loss = self.consistency.laplacian_loss(modality_feats, normalized_adjacency) * lambda_lap
        con_loss = self.consistency.contrastive_loss(modality_feats) * lambda_con

        # classification loss if labels available (single-label cross-entropy)
        cls_loss = torch.tensor(0.0, device=fused_feats.device)
        logits = self.classifier_head(fused_feats)
        if "labels" in batch:
            labels = batch["labels"].long().view(-1)
            cls_loss = nn.functional.cross_entropy(logits, labels)

        ret = {
            "text_feats": text_feats,
            "image_feats": image_feats,
            "cls_feats": cls_feats,
            "raw_cls_feats": x[:, 0],
            "image_labels": image_labels,
            "image_masks": image_masks,
            "text_labels": text_labels,
            "text_ids": text_ids,
            "text_masks": text_masks,
            "patch_index": patch_index,
            # PAG-MPD additions
            "routing_context": routing_context,
            "bar_z": bar_z,
            "p_final": p_final,
            "loss/peak": loss_peak * lambda_peak,
            "loss/div": loss_div * lambda_div,
            "fused_feats": fused_feats,
            # KD & consistency losses
            "loss/kd": kd_out["loss_kd"] * lambda_kd,
            "loss/kd_weighted": kd_out["loss_kd_weighted"] * lambda_kd,
            "loss/lap": lap_loss,
            "loss/con": con_loss,
            "loss/cls": cls_loss,
            "logits": logits,
        }
        
        return ret
    
    def training_step(self, batch, batch_idx):
        """Training step"""
        vilt_utils.set_task(self)
        output = self(batch)
        total_loss = sum([v for k, v in output.items() if "loss" in k])
        return total_loss
    
    def training_epoch_end(self, outs):
        """Training epoch end"""
        vilt_utils.epoch_wrapup(self)
    
    def validation_step(self, batch, batch_idx):
        """Validation step"""
        vilt_utils.set_task(self)
        output = self(batch)
    
    def validation_epoch_end(self, outs):
        """Validation epoch end"""
        vilt_utils.epoch_wrapup(self)
    
    def test_step(self, batch, batch_idx):
        """Test step"""
        vilt_utils.set_task(self)
        output = self(batch)
        return output
    
    def test_epoch_end(self, outs):
        """Test epoch end"""
        vilt_utils.epoch_wrapup(self)
    
    def configure_optimizers(self):
        """Configure optimizers"""
        return vilt_utils.set_schedule(self)
