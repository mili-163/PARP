"""
Core utilities for PAG-MPD model
"""

import torch
import torch.nn as nn
import numpy as np


def init_weights(module):
    """Initialize module weights"""
    if isinstance(module, (nn.Linear, nn.Embedding)):
        module.weight.data.normal_(mean=0.0, std=0.02)
    elif isinstance(module, nn.LayerNorm):
        module.bias.data.zero_()
        module.weight.data.fill_(1.0)
    if isinstance(module, nn.Linear) and module.bias is not None:
        module.bias.data.zero_()


def compute_missing_pattern_stats(missing_mask):
    """
    Compute statistics for missing patterns
    
    Args:
        missing_mask: Binary mask r_i ∈ {0,1}^M indicating missing modalities
        
    Returns:
        dict: Statistics including mean, variance, and observed set
    """
    # Convert to float for computation
    mask_float = missing_mask.float()
    
    # Compute statistics
    mean_missing = torch.mean(mask_float, dim=-1)  # Proportion of observed modalities
    var_missing = torch.var(mask_float, dim=-1)    # Dispersion of missingness patterns
    
    # Get observed set for each sample
    observed_sets = []
    for i in range(missing_mask.shape[0]):
        observed = torch.where(missing_mask[i] == 1)[0].tolist()
        observed_sets.append(observed)
    
    return {
        'mean': mean_missing,
        'var': var_missing,
        'observed_sets': observed_sets,
        'num_observed': torch.sum(missing_mask, dim=-1)
    }


def create_modality_graph(num_modalities, prior_adjacency=None):
    """
    Create modality graph with prior knowledge and learnable weights
    
    Args:
        num_modalities: Number of modalities M
        prior_adjacency: Prior adjacency matrix A_prior ∈ {0,1}^{M×M}
        
    Returns:
        tuple: (adjacency_matrix, learnable_weights)
    """
    # Initialize prior adjacency matrix (fully connected if not provided)
    if prior_adjacency is None:
        prior_adjacency = torch.ones(num_modalities, num_modalities)
        # Remove self-loops
        prior_adjacency.fill_diagonal_(0)
    
    # Initialize learnable weights
    learnable_weights = nn.Parameter(
        torch.randn(num_modalities, num_modalities) * 0.1
    )
    
    # Combined adjacency matrix: A = A_prior ⊙ A_learned
    adjacency_matrix = prior_adjacency * torch.sigmoid(learnable_weights)
    
    return adjacency_matrix, learnable_weights


def normalize_adjacency_matrix(adjacency_matrix):
    """
    Normalize adjacency matrix using diagonal degree matrix
    
    Args:
        adjacency_matrix: Adjacency matrix A
        
    Returns:
        torch.Tensor: Normalized adjacency matrix D^{-1/2} A D^{-1/2}
    """
    # Compute degree matrix
    degree = torch.sum(adjacency_matrix, dim=-1)
    degree_sqrt_inv = torch.pow(degree + 1e-8, -0.5)  # Add small epsilon for numerical stability
    
    # Create diagonal degree matrix
    degree_matrix = torch.diag(degree_sqrt_inv)
    
    # Normalize: D^{-1/2} A D^{-1/2}
    normalized_adj = torch.mm(torch.mm(degree_matrix, adjacency_matrix), degree_matrix)
    
    return normalized_adj


def gumbel_top_k_sampling(logits, k, temperature=1.0, training=True):
    """
    Gumbel-Top-K sampling for sparse routing
    
    Args:
        logits: Routing logits π ∈ R^K
        k: Number of top paths to select
        temperature: Sampling temperature τ
        training: Whether in training mode
        
    Returns:
        torch.Tensor: Soft routing weights α̃_k
    """
    if training:
        # Add Gumbel noise during training
        gumbel_noise = -torch.log(-torch.log(torch.rand_like(logits) + 1e-8) + 1e-8)
        noisy_logits = (logits + gumbel_noise) / temperature
    else:
        noisy_logits = logits / temperature
    
    # Softmax to get soft weights
    soft_weights = torch.softmax(noisy_logits, dim=-1)
    
    # Select top-k during inference
    if not training:
        _, top_k_indices = torch.topk(soft_weights, k, dim=-1)
        hard_weights = torch.zeros_like(soft_weights)
        hard_weights.scatter_(-1, top_k_indices, 1.0)
        return hard_weights
    
    return soft_weights


def compute_dirichlet_parameters(logits, num_classes):
    """
    Compute Dirichlet distribution parameters from logits
    
    Args:
        logits: Raw logits from model
        num_classes: Number of classes C
        
    Returns:
        torch.Tensor: Dirichlet parameters α ∈ R_{>0}^C
    """
    # Apply softplus to ensure positive parameters
    alpha = torch.nn.functional.softplus(logits) + 1.0  # +1 ensures α > 0
    return alpha


def compute_dirichlet_kl_divergence(alpha_1, alpha_2):
    """
    Compute KL divergence between two Dirichlet distributions
    
    Args:
        alpha_1: Parameters of first Dirichlet distribution
        alpha_2: Parameters of second Dirichlet distribution
        
    Returns:
        torch.Tensor: KL divergence
    """
    # Sum of parameters
    sum_alpha_1 = torch.sum(alpha_1, dim=-1, keepdim=True)
    sum_alpha_2 = torch.sum(alpha_2, dim=-1, keepdim=True)
    
    # Digamma functions
    digamma_alpha_1 = torch.digamma(alpha_1)
    digamma_sum_alpha_1 = torch.digamma(sum_alpha_1)
    digamma_alpha_2 = torch.digamma(alpha_2)
    digamma_sum_alpha_2 = torch.digamma(sum_alpha_2)
    
    # Log gamma functions
    log_gamma_alpha_1 = torch.lgamma(alpha_1)
    log_gamma_sum_alpha_1 = torch.lgamma(sum_alpha_1)
    log_gamma_alpha_2 = torch.lgamma(alpha_2)
    log_gamma_sum_alpha_2 = torch.lgamma(sum_alpha_2)
    
    # KL divergence formula
    kl_div = (
        log_gamma_sum_alpha_2 - log_gamma_sum_alpha_1
        - torch.sum(log_gamma_alpha_2 - log_gamma_alpha_1, dim=-1, keepdim=True)
        + torch.sum((alpha_1 - alpha_2) * (digamma_alpha_1 - digamma_sum_alpha_1), dim=-1, keepdim=True)
    )
    
    return kl_div


def compute_uncertainty_weights(dirichlet_alpha):
    """
    Compute uncertainty weights for distillation
    
    Args:
        dirichlet_alpha: Dirichlet parameters α
        
    Returns:
        torch.Tensor: Uncertainty weights w_i
    """
    # Compute covariance matrix of Dirichlet distribution
    sum_alpha = torch.sum(dirichlet_alpha, dim=-1, keepdim=True)
    
    # Variance of each component
    variance = (dirichlet_alpha * (sum_alpha - dirichlet_alpha)) / (
        sum_alpha * sum_alpha * (sum_alpha + 1)
    )
    
    # Trace of covariance matrix (total uncertainty)
    total_uncertainty = torch.sum(variance, dim=-1)
    
    # Uncertainty weights (inverse of uncertainty)
    weights = 1.0 / (1.0 + total_uncertainty)
    
    return weights


def apply_low_rank_adapter(x, adapter_matrix):
    """
    Apply low-rank adapter to input
    
    Args:
        x: Input features
        adapter_matrix: Low-rank adapter A_k^m = U_k^m V_k^{m⊤}
        
    Returns:
        torch.Tensor: Adapted features
    """
    # Adapter(x) = x + A_k^m x
    adapted_x = x + torch.mm(x, adapter_matrix)
    return adapted_x


def compute_graph_laplacian_loss(embeddings, adjacency_matrix):
    """
    Compute graph Laplacian regularization loss
    
    Args:
        embeddings: Modality embeddings
        adjacency_matrix: Graph adjacency matrix
        
    Returns:
        torch.Tensor: Laplacian loss
    """
    num_modalities = embeddings.shape[1]
    laplacian_loss = 0.0
    
    for i in range(num_modalities):
        for j in range(num_modalities):
            if adjacency_matrix[i, j] > 0:  # Only for connected modalities
                diff = embeddings[:, i] - embeddings[:, j]
                laplacian_loss += adjacency_matrix[i, j] * torch.sum(diff ** 2)
    
    return laplacian_loss


def compute_contrastive_loss(embeddings, temperature=0.07):
    """
    Compute cross-modal contrastive loss
    
    Args:
        embeddings: Modality embeddings
        temperature: Contrastive temperature
        
    Returns:
        torch.Tensor: Contrastive loss
    """
    batch_size, num_modalities, embed_dim = embeddings.shape
    
    # Normalize embeddings
    embeddings = torch.nn.functional.normalize(embeddings, dim=-1)
    
    # Compute similarity matrix
    similarity_matrix = torch.bmm(embeddings, embeddings.transpose(1, 2)) / temperature
    
    # Create positive pairs (same sample, different modalities)
    positive_mask = torch.eye(num_modalities, device=embeddings.device).unsqueeze(0)
    positive_mask = positive_mask.expand(batch_size, -1, -1)
    
    # Compute contrastive loss
    exp_sim = torch.exp(similarity_matrix)
    positive_sim = exp_sim * positive_mask
    negative_sim = exp_sim * (1 - positive_mask)
    
    # Loss for each positive pair
    loss = -torch.log(positive_sim.sum(dim=-1) / (positive_sim.sum(dim=-1) + negative_sim.sum(dim=-1)))
    
    return loss.mean()


