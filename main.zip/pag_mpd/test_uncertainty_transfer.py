#!/usr/bin/env python3
import os
import sys
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from uncertainty_aware_transfer import TeacherModel
from uncertainty_aware_transfer import UncertaintyDistillation
from uncertainty_aware_transfer import CrossModalConsistency
from uncertainty_aware_transfer.dirichlet_distribution import dirichlet_mean


def main():
    B = 4
    d = 768
    C = 5
    modality_names = ["text", "image"]

    config = {
        'hidden_size': d,
        'num_classes': C,
        'drop_rate': 0.0,
        'fusion_heads': 4,
        'contrastive_tau': 0.07,
        'contrastive_proj': 256,
        'lambda_kd': 1.0,
    }

    # Fake per-modality features (already \bar{z} + p_final)
    modality_feats = {m: torch.randn(B, d) for m in modality_names}

    # 1) Teacher alpha
    teacher = TeacherModel(config)
    tea_out = teacher(modality_feats)
    alpha_t = tea_out['alpha']  # (B,C)
    assert alpha_t.shape == (B, C)
    print('✓ teacher alpha:', alpha_t.shape)

    # 2) Student alpha (fake)
    student_alpha = torch.nn.functional.softplus(torch.randn(B, C)) + 1.0

    # 3) KD losses
    kd = UncertaintyDistillation(config)
    kd_out = kd(alpha_t, student_alpha)
    print('✓ KD (mean):', float(kd_out['loss_kd']), 'KD (weighted):', float(kd_out['loss_kd_weighted']))

    # 4) Fusion via MHAttn
    cmc = CrossModalConsistency(config)
    fused = cmc.fuse(modality_feats)
    assert fused.shape == (B, d)
    print('✓ fused feat:', fused.shape)

    # 5) Laplacian / Contrastive losses
    A = torch.tensor([[0.0, 1.0],[1.0, 0.0]])
    lap = cmc.laplacian_loss(modality_feats, A)
    con = cmc.contrastive_loss(modality_feats)
    print('✓ laplacian:', float(lap), 'contrastive:', float(con))

    print('\nAll uncertainty-aware transfer tests passed.')


if __name__ == '__main__':
    main()
