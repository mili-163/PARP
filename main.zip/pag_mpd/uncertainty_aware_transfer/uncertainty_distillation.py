import torch
import torch.nn as nn
from typing import Dict

from .dirichlet_distribution import dirichlet_kl, uncertainty_weight_from_alpha


class UncertaintyDistillation(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.lambda_kd = config.get('lambda_kd', 1.0)

    def forward(self, teacher_alpha: torch.Tensor, student_alpha: torch.Tensor) -> Dict[str, torch.Tensor]:
        # KD = KL(Dir(teacher) || Dir(student))
        kd = dirichlet_kl(teacher_alpha, student_alpha)  # (B,)
        w = uncertainty_weight_from_alpha(teacher_alpha)  # (B,)
        kd_weighted = (w * kd).mean()
        return {
            'loss_kd': kd.mean() * self.lambda_kd,
            'loss_kd_weighted': kd_weighted * self.lambda_kd,
            'weight': w,
        }
