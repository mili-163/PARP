import torch
import torch.nn as nn
from typing import Dict


class TeacherModel(nn.Module):
    """
    Full-modality teacher producing Dirichlet parameters to capture uncertainty:
      alpha_tea = softplus(W_alpha * Agg({z^m})) + 1
    """

    def __init__(self, config: Dict):
        super().__init__()
        self.hidden = config["hidden_size"]
        self.num_classes = config.get("num_classes", 2)
        self.agg_type = config.get("teacher_agg", "mean")  # mean / attn
        self.drop = config.get("drop_rate", 0.1)

        proj_in = self.hidden
        self.proj = nn.Sequential(
            nn.Linear(proj_in, proj_in), nn.GELU(), nn.Dropout(self.drop), nn.Linear(proj_in, self.num_classes)
        )
        if self.agg_type == "attn":
            self.query = nn.Parameter(torch.randn(1, 1, self.hidden))
            self.attn = nn.MultiheadAttention(self.hidden, num_heads=8, batch_first=True)

    def aggregate(self, modality_embeddings: Dict[str, torch.Tensor]) -> torch.Tensor:
        # modality_embeddings: dict m -> (B, d)
        xs = torch.stack(list(modality_embeddings.values()), dim=1)  # (B, M, d)
        if self.agg_type == "mean":
            return xs.mean(dim=1)
        # attention pooling with a learnable query
        B = xs.size(0)
        q = self.query.expand(B, -1, -1)  # (B,1,d)
        out, _ = self.attn(q, xs, xs)
        return out.squeeze(1)

    def forward(self, modality_embeddings: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        h = self.aggregate(modality_embeddings)  # (B, d)
        logits = self.proj(h)  # (B, C)
        alpha = torch.nn.functional.softplus(logits) + 1.0
        return {"alpha": alpha, "logits": logits}
