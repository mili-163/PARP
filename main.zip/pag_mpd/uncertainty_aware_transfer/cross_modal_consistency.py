import torch
import torch.nn as nn
from typing import Dict


class CrossModalConsistency(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.hidden = config['hidden_size']
        self.num_heads = config.get('fusion_heads', 8)
        self.drop = config.get('drop_rate', 0.1)
        self.temperature = config.get('contrastive_tau', 0.07)

        self.q_proj = nn.Linear(self.hidden, self.hidden)
        self.k_proj = nn.Linear(self.hidden, self.hidden)
        self.v_proj = nn.Linear(self.hidden, self.hidden)
        self.mha = nn.MultiheadAttention(self.hidden, self.num_heads, batch_first=True, dropout=self.drop)

        # projection head phi for contrastive
        proj_dim = config.get('contrastive_proj', self.hidden)
        self.proj = nn.Sequential(
            nn.Linear(self.hidden, proj_dim), nn.GELU(), nn.Linear(proj_dim, proj_dim)
        )

    def fuse(self, modality_feats: Dict[str, torch.Tensor]) -> torch.Tensor:
        # modality_feats: dict m -> (B, d)
        xs = torch.stack(list(modality_feats.values()), dim=1)  # (B, M, d)
        Q = self.q_proj(xs)
        K = self.k_proj(xs)
        V = self.v_proj(xs)
        fused, _ = self.mha(Q, K, V)
        # use first token pooled mean as fused rep
        return fused.mean(dim=1)  # (B, d)

    def laplacian_loss(self, modality_feats: Dict[str, torch.Tensor], adjacency: torch.Tensor) -> torch.Tensor:
        # sum_{m,m'} A_{mm'} || z_m - z_{m'} ||^2
        names = list(modality_feats.keys())
        Z = torch.stack([modality_feats[n] for n in names], dim=1)  # (B, M, d)
        M = Z.size(1)
        loss = 0.0
        for i in range(M):
            for j in range(M):
                if adjacency[i, j] > 0:
                    diff = Z[:, i] - Z[:, j]
                    loss = loss + adjacency[i, j] * (diff.pow(2).sum(dim=-1)).mean()
        return loss

    def contrastive_loss(self, modality_feats: Dict[str, torch.Tensor]) -> torch.Tensor:
        # instance-level cross-modal alignment across modalities
        names = list(modality_feats.keys())
        Z = torch.stack([self.proj(modality_feats[n]) for n in names], dim=1)  # (B,M,d')
        Z = torch.nn.functional.normalize(Z, dim=-1)
        B, M, D = Z.shape
        loss = 0.0
        for i in range(M):
            for j in range(M):
                if i == j:
                    continue
                # similarity within batch
                sim = torch.matmul(Z[:, i], Z[:, j].transpose(0, 1)) / self.temperature  # (B,B)
                labels = torch.arange(B, device=Z.device)
                loss = loss + nn.CrossEntropyLoss()(sim, labels)
        return loss / max(M * (M - 1), 1)
