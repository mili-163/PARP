import torch
from typing import Tuple


def dirichlet_mean(alpha: torch.Tensor) -> torch.Tensor:
    return alpha / alpha.sum(dim=-1, keepdim=True)


def dirichlet_variance(alpha: torch.Tensor) -> torch.Tensor:
    S = alpha.sum(dim=-1, keepdim=True)
    return (alpha * (S - alpha)) / (S * S * (S + 1.0))


def dirichlet_kl(alpha_p: torch.Tensor, alpha_q: torch.Tensor) -> torch.Tensor:
    # KL(Dir(alpha_p) || Dir(alpha_q))
    sum_p = alpha_p.sum(dim=-1, keepdim=True)
    sum_q = alpha_q.sum(dim=-1, keepdim=True)
    lgamma = torch.lgamma
    digamma = torch.digamma
    term1 = lgamma(sum_p) - lgamma(sum_q)
    term2 = (lgamma(alpha_q) - lgamma(alpha_p)).sum(dim=-1, keepdim=True)
    term3 = ((alpha_p - alpha_q) * (digamma(alpha_p) - digamma(sum_p))).sum(dim=-1, keepdim=True)
    return (term1 + term2 + term3).squeeze(-1)


def uncertainty_weight_from_alpha(alpha: torch.Tensor) -> torch.Tensor:
    # w_i = 1 / (1 + Tr(Cov[pi])) ; Tr = sum of variances
    var = dirichlet_variance(alpha)  # (B, C)
    tr = var.sum(dim=-1)             # (B,)
    return 1.0 / (1.0 + tr)
