"""
Uncertainty-Aware Knowledge Transfer Component

This module implements the third component of PAG-MPD:
- Uncertainty-aware distillation with Dirichlet distribution
- Prompt-guided cross-modal consistency
- Graph Laplacian regularization and contrastive learning
"""

from .teacher_model import TeacherModel
from .uncertainty_distillation import UncertaintyDistillation
from .cross_modal_consistency import CrossModalConsistency
from .dirichlet_distribution import (
    dirichlet_mean,
    dirichlet_variance,
    dirichlet_kl,
    uncertainty_weight_from_alpha,
)

__all__ = [
    'TeacherModel',
    'UncertaintyDistillation',
    'CrossModalConsistency',
    'dirichlet_mean',
    'dirichlet_variance',
    'dirichlet_kl',
    'uncertainty_weight_from_alpha',
]


