import torch
import torch.nn as nn
from typing import Dict, Tuple


class LowRankAdapters(nn.Module):
    """
    Low-Rank Adapters per path and per modality.

    A_k^m = U_k^m V_k^{m^T}, with U,V in R^{d x d_r}.
    Adapter(x; A) = x + A x.
    """

    def __init__(self, config: Dict):
        super().__init__()
        self.hidden = config["hidden_size"]  # d
        self.rank = config.get("adapter_rank", 16)  # d_r
        self.num_paths = config.get("num_paths", 8)
        self.modality_names = config.get("modality_names", ["text", "image"])  # length M

        # For simplicity, use small MLPs to predict U,V given conditioning vector
        cond_dim = config.get("adapter_cond_dim", 256)  # condition input dim
        self.cond_proj = nn.Sequential(
            nn.Linear(cond_dim, cond_dim), nn.GELU(), nn.Linear(cond_dim, cond_dim)
        )

        # One head per (path, modality) to generate U and V
        self.U_heads = nn.ModuleDict()
        self.V_heads = nn.ModuleDict()
        for k in range(self.num_paths):
            for m in self.modality_names:
                key = f"{k}:{m}"
                self.U_heads[key] = nn.Linear(cond_dim, self.hidden * self.rank)
                self.V_heads[key] = nn.Linear(cond_dim, self.hidden * self.rank)

    def forward(self, conditioning: torch.Tensor) -> Dict[str, Dict[str, torch.Tensor]]:
        """
        Args:
            conditioning: (B, cond_dim) e.g., could be u_i or a context fusion

        Returns:
            dict[path_key][modality] with 'U' and 'V' of shapes (B, d, r)
        """
        B, cond_dim = conditioning.shape
        h = self.cond_proj(conditioning)

        out: Dict[str, Dict[str, torch.Tensor]] = {}
        for k in range(self.num_paths):
            path_key = str(k)
            out[path_key] = {}
            for m in self.modality_names:
                key = f"{k}:{m}"
                U = self.U_heads[key](h).view(B, self.hidden, self.rank)
                V = self.V_heads[key](h).view(B, self.hidden, self.rank)
                out[path_key][m] = {"U": U, "V": V}
        return out

    @staticmethod
    def apply_adapter(x: torch.Tensor, U: torch.Tensor, V: torch.Tensor) -> torch.Tensor:
        """
        Apply Adapter(x) = x + A x with A = U V^T.
        Shapes:
          x: (B, d)
          U: (B, d, r)
          V: (B, d, r)
        """
        A_x = torch.matmul(U, torch.matmul(V.transpose(-1, -2), x.unsqueeze(-1))).squeeze(-1)
        return x + A_x


