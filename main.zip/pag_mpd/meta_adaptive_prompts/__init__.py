"""
Meta-Adaptive Prompt Generation Component

This module implements the second component of PAG-MPD:
- Differentiable sparse routing with Gumbel-Top-S sampling
- Meta-adaptive prompt generation with low-rank adapters
- Pattern-aware fusion for enhanced multimodal robustness
"""

from .sparse_routing import SparseRouting
from .prompt_network import PromptNetwork
from .low_rank_adapters import LowRankAdapters
from .gumbel_sampling import gumbel_top_s_softmax

__all__ = [
    'SparseRouting',
    'PromptNetwork',
    'LowRankAdapters', 
    'gumbel_top_s_softmax'
]
