import torch
import torch.nn as nn
from typing import Dict, Tuple


class PromptNetwork(nn.Module):
    r"""
    Prompt Network H_k that generates T_p meta-adaptive prompt tokens per modality,
    conditioned on modality embeddings and missing-pattern vector u_i (statistical embedding).
    """

    def __init__(self, config: Dict):
        super().__init__()
        self.hidden = config["hidden_size"]  # d
        self.prompt_len = config.get("prompt_len", 4)  # T_p
        self.num_paths = config.get("num_paths", 8)
        self.modality_names = config.get("modality_names", ["text", "image"])  # length M

        # cond_dim is the actual input feature dim to the prompt MLP
        # In our usage we pass concat([\tilde{z}_i^m, u_i]) of dim (d + d_u)
        cond_dim = config.get("prompt_cond_dim", 256)
        proj_hidden = config.get("prompt_hidden", 512)
        self.drop = config.get("drop_rate", 0.1)

        # Condition projection (shared)
        self.cond_proj = nn.Sequential(
            nn.Linear(cond_dim, proj_hidden),
            nn.GELU(),
            nn.Dropout(self.drop),
            nn.Linear(proj_hidden, proj_hidden),
            nn.GELU(),
        )

        # Heads for generating prompts per (path, modality)
        self.prompt_heads = nn.ModuleDict()
        for k in range(self.num_paths):
            for m in self.modality_names:
                key = f"{k}:{m}"
                self.prompt_heads[key] = nn.Linear(proj_hidden, self.prompt_len * self.hidden)

    def forward(self,
                modality_embeddings: Dict[str, torch.Tensor],
                statistical_embedding: torch.Tensor) -> Dict[str, Dict[str, torch.Tensor]]:
        """
        Args:
            modality_embeddings: dict name -> (B, d) for each modality's current embedding \tilde{z}_i^m
            statistical_embedding: (B, d_u) u_i

        Returns:
            dict[path_key][modality] -> prompts tensor (B, T_p, d)
        """
        B = statistical_embedding.shape[0]
        out: Dict[str, Dict[str, torch.Tensor]] = {}
        for k in range(self.num_paths):
            path_key = str(k)
            out[path_key] = {}
            for m, z in modality_embeddings.items():
                # concat [\tilde{z}_i^m, u_i]
                cond = torch.cat([z, statistical_embedding], dim=-1)
                h = self.cond_proj(cond)
                key = f"{k}:{m}"
                p = self.prompt_heads[key](h).view(B, self.prompt_len, self.hidden)
                out[path_key][m] = p
        return out

    # Simple PromptAttn: single-head scaled dot-product between z and prompts
    # Returns a prompt-enhanced feature of shape (B, d)
    def prompt_attention(self, z: torch.Tensor, prompts: torch.Tensor) -> torch.Tensor:
        """
        Args:
            z: (B, d)
            prompts: (B, T_p, d)
        Returns:
            (B, d)
        """
        B, Tp, d = prompts.shape
        q = z.unsqueeze(1)  # (B,1,d)
        # scores: (B, 1, T_p)
        scores = torch.matmul(q, prompts.transpose(-1, -2)) / (d ** 0.5)
        attn = torch.softmax(scores, dim=-1)  # (B,1,T_p)
        # weighted sum: (B,1,d) -> (B,d)
        out = torch.matmul(attn, prompts).squeeze(1)
        return out

    @staticmethod
    def combine_with_adapter(
        modality_embeddings: Dict[str, torch.Tensor],
        prompts_for_path: Dict[str, torch.Tensor],
        adapters_for_path: Dict[str, Dict[str, torch.Tensor]],
        apply_adapter_fn,
        prompt_attn_fn,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute \hat{z}_i^{m,k} = Adapter(\tilde{z}_i^m; A_k^m) + PromptAttn(\tilde{z}_i^m, {P_k^{m,t}})

        Args:
            modality_embeddings: dict modality -> (B,d)
            prompts_for_path: dict modality -> (B,T_p,d)
            adapters_for_path: dict modality -> {U: (B,d,r), V: (B,d,r)}
            apply_adapter_fn: function(x,U,V)->(B,d)
            prompt_attn_fn: function(z, prompts)->(B,d)
        Returns:
            dict modality -> (B,d)
        """
        out: Dict[str, torch.Tensor] = {}
        for m, z in modality_embeddings.items():
            U = adapters_for_path[m]["U"]
            V = adapters_for_path[m]["V"]
            z_adapt = apply_adapter_fn(z, U, V)
            z_prompt = prompt_attn_fn(z, prompts_for_path[m])
            out[m] = z_adapt + z_prompt
        return out

    @staticmethod
    def aggregate_prompts(prompts_per_path: Dict[str, Dict[str, torch.Tensor]],
                          weights: torch.Tensor,
                          modality_names) -> Dict[str, torch.Tensor]:
        """
        Aggregate prompts across selected paths using soft weights.

        Args:
            prompts_per_path: dict[path][modality] -> (B, T_p, d)
            weights: (B, K)

        Returns:
            dict modality -> (B, d) aggregated prompt p_final^m (mean over T_p, weighted over K)
        """
        B, K = weights.shape
        agg: Dict[str, torch.Tensor] = {}
        for m in modality_names:
            # stack over K: (B, K, T_p, d)
            stacked = torch.stack([prompts_per_path[str(k)][m] for k in range(K)], dim=1)
            # mean over T_p -> (B, K, d)
            mean_tp = stacked.mean(dim=2)
            # weighted sum over K -> (B, d)
            w = weights.unsqueeze(-1)
            agg[m] = (mean_tp * w).sum(dim=1)
        return agg
