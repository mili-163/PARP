import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple

from .gumbel_sampling import gumbel_top_s_softmax


class SparseRouting(nn.Module):
    """
    Differentiable Sparse Routing over K candidate paths.

    Given routing context c_i, produce logits π, sample/choose Top-S paths via Gumbel-Top-S,
    and compute sparsity/diversity regularizations.
    """

    def __init__(self, config: Dict):
        super().__init__()
        self.hidden = config.get("routing_hidden", 512)
        self.num_paths = config.get("num_paths", 8)  # K
        self.top_s = config.get("top_s", 2)          # S
        self.temperature = config.get("gumbel_tau", 1.0)
        self.drop = config.get("drop_rate", 0.1)

        routing_in = config.get("routing_in_dim")  # must be set to d_c from graph encoder
        if routing_in is None:
            raise ValueError("config['routing_in_dim'] must be provided (routing context dimension d_c)")

        self.mlp_route = nn.Sequential(
            nn.Linear(routing_in, self.hidden),
            nn.LayerNorm(self.hidden),
            nn.GELU(),
            nn.Dropout(self.drop),
            nn.Linear(self.hidden, self.num_paths)
        )

    def forward(self, routing_context: torch.Tensor, training: bool = True) -> Dict[str, torch.Tensor]:
        """
        Args:
            routing_context: (B, d_c)
            training: training or inference mode for sampling

        Returns:
            dict with keys:
              - logits: (B, K)
              - weights: (B, K) soft (train) or hard (infer)
              - top_indices: (B, S)
              - loss_peak: ()
              - loss_div: ()
        """
        logits = self.mlp_route(routing_context)  # (B, K)
        weights, top_idx = gumbel_top_s_softmax(
            logits, top_s=self.top_s, temperature=self.temperature, training=training, hard_inference=True
        )

        # L_peak = - sum_k alpha_ik^2
        loss_peak = -(weights.pow(2).sum(dim=-1)).mean()

        # L_div = - sum_k bar_alpha_k log bar_alpha_k, where bar over batch
        bar_alpha = weights.mean(dim=0)  # (K,)
        bar_alpha = torch.clamp(bar_alpha, min=1e-8)
        loss_div = -(bar_alpha * torch.log(bar_alpha)).sum()

        return {
            'logits': logits,
            'weights': weights,
            'top_indices': top_idx,
            'loss_peak': loss_peak,
            'loss_div': loss_div,
        }


