import torch
import torch.nn.functional as F
from typing import Tuple


def sample_gumbel(shape, device, eps: float = 1e-8):
    u = torch.rand(shape, device=device)
    return -torch.log(-torch.log(u + eps) + eps)


def gumbel_top_s_softmax(logits: torch.Tensor,
                         top_s: int,
                         temperature: float = 1.0,
                         training: bool = True,
                         hard_inference: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Gumbel-Top-S with softmax weights.

    Args:
        logits: (B, K)
        top_s: number of paths to select
        temperature: softmax temperature
        training: if True, add Gumbel noise
        hard_inference: if False, always return soft weights; if True and not training, return hard one-hot top-S

    Returns:
        weights: (B, K) soft (training) or hard (inference) weights
        top_indices: (B, top_s) indices of selected paths (best-effort in training using current weights)
    """
    B, K = logits.shape
    if training:
        g = sample_gumbel((B, K), device=logits.device)
        noisy = (logits + g) / max(temperature, 1e-6)
        weights = F.softmax(noisy, dim=-1)
    else:
        weights = F.softmax(logits / max(temperature, 1e-6), dim=-1)

    top_vals, top_idx = torch.topk(weights, k=min(top_s, K), dim=-1)

    if not training and hard_inference:
        hard = torch.zeros_like(weights)
        hard.scatter_(-1, top_idx, 1.0)
        return hard, top_idx

    return weights, top_idx


