"""
Pattern-Aware Graph Encoder

This module implements the main Pattern-Aware Graph Encoder that integrates all components:
1. Statistical Embedding: u_i = MLP([1/max(|O_i|, 1) * sum_{m in O_i} z_i^m; mean(r_i); var(r_i)])
2. Cross-modal Dependencies: A = A_prior ⊙ A_learned
3. Modality Embeddings: z̃_i^m = sum_{m' in M} (D^{-1/2} A D^{-1/2})_{mm'} γ_{mm'}(r_i) z_i^{m'}

Final routing context: c_i = [concat(z̃_i^1, ..., z̃_i^M); u_i] ∈ R^{d_c}
where d_c = M · d + d_u
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional

from .statistical_embedding import StatisticalEmbedding
from .cross_modal_dependencies import CrossModalDependencies
from .modality_embeddings import ModalityEmbeddings


class PatternAwareGraphEncoder(nn.Module):
    """
    Pattern-Aware Graph Encoder for handling incomplete multimodal inputs
    
    This encoder integrates three key components:
    1. Statistical embedding for aggregating observed semantics
    2. Cross-modal dependencies modeling via graph
    3. Modality embeddings updated via gated graph propagation
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        self.hidden_size = config["hidden_size"]
        self.num_modalities = config.get("num_modalities", 2)  # text and image by default
        self.modality_names = config.get("modality_names", ["text", "image"])
        
        # Initialize components
        self.statistical_embedding = StatisticalEmbedding(config)
        self.cross_modal_dependencies = CrossModalDependencies(config)
        self.modality_embeddings = ModalityEmbeddings(config)
        
        # Compute routing context dimension
        self.statistical_embed_dim = self.statistical_embedding.get_embedding_dim()
        self.routing_context_dim = self.num_modalities * self.hidden_size + self.statistical_embed_dim
        
        # Optional: Add a final projection layer for routing context
        self.use_final_projection = config.get("use_final_projection", False)
        if self.use_final_projection:
            self.final_projection = nn.Sequential(
                nn.Linear(self.routing_context_dim, self.routing_context_dim),
                nn.LayerNorm(self.routing_context_dim),
                nn.GELU(),
                nn.Dropout(config.get("drop_rate", 0.1))
            )
    
    def encode_modalities(self, 
                         text_embeds: torch.Tensor,
                         image_embeds: torch.Tensor,
                         missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Encode modalities using modality-specific encoders
        
        Args:
            text_embeds: Text embeddings (batch_size, hidden_size)
            image_embeds: Image embeddings (batch_size, hidden_size)
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Dict mapping modality names to encoded embeddings
        """
        batch_size = text_embeds.shape[0]
        device = text_embeds.device
        
        # Create modality embeddings dictionary
        modality_embeddings = {
            "text": text_embeds,
            "image": image_embeds
        }
        
        # Handle missing modalities by replacing with placeholders
        # For missing modalities, we use zero vectors as placeholders
        for i, modality_name in enumerate(self.modality_names):
            if i < missing_mask.shape[1]:  # Safety check
                missing_indices = missing_mask[:, i] == 0
                if torch.any(missing_indices):
                    # Replace missing modalities with zero vectors
                    modality_embeddings[modality_name][missing_indices] = 0.0
        
        return modality_embeddings
    
    def forward(self, 
                text_embeds: torch.Tensor,
                image_embeds: torch.Tensor,
                missing_mask: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for Pattern-Aware Graph Encoder
        
        Args:
            text_embeds: Text embeddings (batch_size, hidden_size)
            image_embeds: Image embeddings (batch_size, hidden_size)
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Routing context c_i ∈ R^{d_c} (batch_size, routing_context_dim)
        """
        # Step 1: Encode modalities (handle missing modalities with placeholders)
        modality_embeddings = self.encode_modalities(text_embeds, image_embeds, missing_mask)
        
        # Step 2: Compute statistical embedding u_i
        statistical_embedding = self.statistical_embedding(modality_embeddings, missing_mask)
        
        # Step 3: Compute cross-modal dependencies
        dependency_info = self.cross_modal_dependencies(missing_mask)
        normalized_adjacency = dependency_info['normalized_adjacency']
        
        # Step 4: Update modality embeddings via gated graph propagation
        updated_modality_embeddings = self.modality_embeddings(
            modality_embeddings, missing_mask, normalized_adjacency
        )
        
        # Step 5: Create routing context c_i = [concat(z̃_i^1, ..., z̃_i^M); u_i]
        # Concatenate updated modality embeddings
        modality_embeddings_list = []
        for modality_name in self.modality_names:
            if modality_name in updated_modality_embeddings:
                modality_embeddings_list.append(updated_modality_embeddings[modality_name])
        
        # Concatenate all modality embeddings
        concatenated_embeddings = torch.cat(modality_embeddings_list, dim=-1)  # (batch_size, num_modalities * hidden_size)
        
        # Concatenate with statistical embedding
        routing_context = torch.cat([concatenated_embeddings, statistical_embedding], dim=-1)  # (batch_size, routing_context_dim)
        
        # Optional: Apply final projection
        if self.use_final_projection:
            routing_context = self.final_projection(routing_context)
        
        return routing_context

    def encode_with_details(self,
                            text_embeds: torch.Tensor,
                            image_embeds: torch.Tensor,
                            missing_mask: torch.Tensor,
                            extra_modalities: Optional[Dict[str, torch.Tensor]] = None) -> Dict[str, torch.Tensor]:
        """
        Extended encoding that returns intermediate artifacts for downstream modules.

        Returns a dict with:
          - routing_context: (B, d_c)
          - updated_modality_embeddings: dict name -> (B, d)
          - statistical_embedding: (B, d_u)
          - normalized_adjacency: (M, M)
        """
        # build base modality embeddings
        modality_embeddings = self.encode_modalities(text_embeds, image_embeds, missing_mask)
        # append extra modalities if provided
        if extra_modalities is not None:
            for k, v in extra_modalities.items():
                modality_embeddings[k] = v
            # update modality_names to include any new ones deterministically
            for k in extra_modalities.keys():
                if k not in self.modality_names:
                    self.modality_names.append(k)
            # adjust internal counts if modality set changed
            self.num_modalities = len(self.modality_names)
        statistical_embedding = self.statistical_embedding(modality_embeddings, missing_mask)
        dependency_info = self.cross_modal_dependencies(missing_mask)
        normalized_adjacency = dependency_info['normalized_adjacency']
        updated_modality_embeddings = self.modality_embeddings(
            modality_embeddings, missing_mask, normalized_adjacency
        )

        modality_embeddings_list = []
        for modality_name in self.modality_names:
            if modality_name in updated_modality_embeddings:
                modality_embeddings_list.append(updated_modality_embeddings[modality_name])
        concatenated_embeddings = torch.cat(modality_embeddings_list, dim=-1)
        routing_context = torch.cat([concatenated_embeddings, statistical_embedding], dim=-1)
        if self.use_final_projection:
            routing_context = self.final_projection(routing_context)

        return {
            'routing_context': routing_context,
            'updated_modality_embeddings': updated_modality_embeddings,
            'statistical_embedding': statistical_embedding,
            'normalized_adjacency': normalized_adjacency,
        }
    
    def get_routing_context_dim(self) -> int:
        """Get the dimension of the routing context"""
        return self.routing_context_dim
    
    def get_statistical_embedding_dim(self) -> int:
        """Get the dimension of the statistical embedding"""
        return self.statistical_embed_dim
    
    def get_graph_info(self) -> Dict:
        """Get information about the graph structure"""
        return self.cross_modal_dependencies.get_graph_info()
    
    def get_dependency_info(self, missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Get detailed dependency information for analysis
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Dict containing dependency information
        """
        return self.cross_modal_dependencies(missing_mask)
    
    def get_gating_analysis(self, missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Get gating analysis for debugging/visualization
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Dict containing gating analysis
        """
        return self.modality_embeddings.analyze_gating_behavior(missing_mask)
    
    def get_statistical_analysis(self, 
                                text_embeds: torch.Tensor,
                                image_embeds: torch.Tensor,
                                missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Get statistical analysis for debugging/visualization
        
        Args:
            text_embeds: Text embeddings (batch_size, hidden_size)
            image_embeds: Image embeddings (batch_size, hidden_size)
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Dict containing statistical analysis
        """
        modality_embeddings = self.encode_modalities(text_embeds, image_embeds, missing_mask)
        stats = self.statistical_embedding.compute_missing_pattern_stats(missing_mask)
        
        return {
            'missing_pattern_stats': stats,
            'modality_embeddings': modality_embeddings
        }
    
    def set_prior_adjacency(self, prior_adjacency: torch.Tensor):
        """
        Set the prior adjacency matrix for cross-modal dependencies
        
        Args:
            prior_adjacency: Prior adjacency matrix ∈ {0,1}^{M×M}
        """
        self.cross_modal_dependencies.set_prior_adjacency(prior_adjacency)
    
    def get_prior_adjacency(self) -> torch.Tensor:
        """Get the current prior adjacency matrix"""
        return self.cross_modal_dependencies.get_prior_adjacency()
    
    def get_learnable_weights(self) -> torch.Tensor:
        """Get the learnable weights for cross-modal dependencies"""
        return self.cross_modal_dependencies.get_learnable_weights()
    
    def analyze_missing_patterns(self, missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Analyze different missing patterns and their effects
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Dict containing analysis of missing patterns
        """
        batch_size, num_modalities = missing_mask.shape
        
        # Analyze missing patterns
        missing_stats = self.statistical_embedding.compute_missing_pattern_stats(missing_mask)
        
        # Get dependency information
        dependency_info = self.cross_modal_dependencies(missing_mask)
        
        # Get gating analysis
        gating_analysis = self.modality_embeddings.analyze_gating_behavior(missing_mask)
        
        return {
            'missing_stats': missing_stats,
            'dependency_info': dependency_info,
            'gating_analysis': gating_analysis,
            'num_observed_modalities': missing_stats['num_observed'],
            'missing_ratio': 1.0 - missing_stats['mean_missing']
        }


