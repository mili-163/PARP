"""
Pattern-Aware Graph Encoding Component

This module implements the first component of PAG-MPD:
- Statistical embedding for aggregating observed semantics and sample-level statistics
- Cross-modal dependencies modeling via graph with prior knowledge and learnable weights
- Modality embeddings updated via gated graph propagation
"""

from .graph_encoder import PatternAwareGraphEncoder
from .statistical_embedding import StatisticalEmbedding
from .cross_modal_dependencies import CrossModalDependencies
from .modality_embeddings import ModalityEmbeddings

__all__ = [
    'PatternAwareGraphEncoder',
    'StatisticalEmbedding', 
    'CrossModalDependencies',
    'ModalityEmbeddings'
]


