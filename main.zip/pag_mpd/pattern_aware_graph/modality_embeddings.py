"""
Modality Embeddings Module

This module implements the modality embeddings component of Pattern-Aware Graph:
z̃_i^m = sum_{m' in M} (D^{-1/2} A D^{-1/2})_{mm'} γ_{mm'}(r_i) z_i^{m'}

where:
- γ_{mm'}(r_i) = σ(a_{mm'}^T r_i + b_{mm'}) ∈ (0,1) scales the influence of m' on m
- σ denotes the sigmoid function
- D^{-1/2} A D^{-1/2} is the normalized adjacency matrix
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional


class ModalityEmbeddings(nn.Module):
    """
    Modality Embeddings Module for Pattern-Aware Graph
    
    Updates each modality via gated graph propagation, where the influence
    of one modality on another is scaled based on the missing pattern.
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        self.hidden_size = config["hidden_size"]
        self.num_modalities = config.get("num_modalities", 2)  # text and image by default
        self.use_gating = config.get("use_gating", True)
        
        # Gating parameters for each modality pair
        # γ_{mm'}(r_i) = σ(a_{mm'}^T r_i + b_{mm'})
        if self.use_gating:
            # Learnable parameters for gating function
            self.gating_weights = nn.Parameter(
                torch.randn(self.num_modalities, self.num_modalities, self.num_modalities) * 0.1
            )  # (num_modalities, num_modalities, num_modalities) for a_{mm'}
            
            self.gating_biases = nn.Parameter(
                torch.randn(self.num_modalities, self.num_modalities) * 0.1
            )  # (num_modalities, num_modalities) for b_{mm'}
            
            # Initialize gating parameters
            self._init_gating_parameters()
    
    def _init_gating_parameters(self):
        """Initialize gating parameters"""
        # Initialize gating weights with small random values
        nn.init.normal_(self.gating_weights, mean=0.0, std=0.1)
        nn.init.normal_(self.gating_biases, mean=0.0, std=0.1)
        
        # Ensure self-gating is strong (diagonal elements)
        for i in range(self.num_modalities):
            self.gating_biases.data[i, i] = 1.0
    
    def compute_gating_weights(self, missing_mask: torch.Tensor) -> torch.Tensor:
        """
        Compute gating weights γ_{mm'}(r_i) = σ(a_{mm'}^T r_i + b_{mm'})
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Gating weights γ_{mm'}(r_i) ∈ (0,1) (batch_size, num_modalities, num_modalities)
        """
        if not self.use_gating:
            # If no gating, return identity matrix
            batch_size = missing_mask.shape[0]
            device = missing_mask.device
            return torch.eye(self.num_modalities, device=device).unsqueeze(0).expand(batch_size, -1, -1)
        
        batch_size, num_modalities = missing_mask.shape
        device = missing_mask.device
        # Ensure dtype compatibility for matmul with floating parameters
        missing_mask = missing_mask.float()
        
        # Compute gating scores: a_{mm'}^T r_i + b_{mm'}
        # gating_weights: (num_modalities, num_modalities, num_modalities)
        # missing_mask: (batch_size, num_modalities)
        
        # Reshape for batch matrix multiplication
        gating_scores = torch.zeros(batch_size, num_modalities, num_modalities, device=device)
        
        for m in range(num_modalities):
            for m_prime in range(num_modalities):
                # a_{mm'}^T r_i + b_{mm'}
                score = torch.matmul(missing_mask, self.gating_weights[m, m_prime]) + self.gating_biases[m, m_prime]
                gating_scores[:, m, m_prime] = score
        
        # Apply sigmoid to get gating weights in (0, 1)
        gating_weights = torch.sigmoid(gating_scores)
        
        return gating_weights
    
    def apply_gated_graph_propagation(self, 
                                    modality_embeddings: Dict[str, torch.Tensor],
                                    normalized_adjacency: torch.Tensor,
                                    gating_weights: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Apply gated graph propagation to update modality embeddings
        
        Args:
            modality_embeddings: Dict mapping modality names to embeddings
                                Each embedding has shape (batch_size, hidden_size)
            normalized_adjacency: Normalized adjacency matrix D^{-1/2} A D^{-1/2}
                                Shape: (num_modalities, num_modalities)
            gating_weights: Gating weights γ_{mm'}(r_i)
                          Shape: (batch_size, num_modalities, num_modalities)
        
        Returns:
            Updated modality embeddings z̃_i^m
        """
        batch_size = list(modality_embeddings.values())[0].shape[0]
        device = list(modality_embeddings.values())[0].device
        
        # Convert modality embeddings to tensor for easier computation
        modality_names = list(modality_embeddings.keys())
        num_modalities = len(modality_names)
        
        # Stack embeddings: (batch_size, num_modalities, hidden_size)
        stacked_embeddings = torch.stack([modality_embeddings[name] for name in modality_names], dim=1)
        
        # Expand normalized adjacency to batch dimension
        # normalized_adjacency: (num_modalities, num_modalities)
        # -> (batch_size, num_modalities, num_modalities)
        adj_expanded = normalized_adjacency.unsqueeze(0).expand(batch_size, -1, -1)
        
        # Apply gating: (D^{-1/2} A D^{-1/2})_{mm'} * γ_{mm'}(r_i)
        gated_adjacency = adj_expanded * gating_weights
        
        # Graph propagation: z̃_i^m = sum_{m' in M} gated_adjacency_{mm'} * z_i^{m'}
        # (batch_size, num_modalities, num_modalities) @ (batch_size, num_modalities, hidden_size)
        # -> (batch_size, num_modalities, hidden_size)
        updated_embeddings = torch.bmm(gated_adjacency, stacked_embeddings)
        
        # Convert back to dictionary
        updated_modality_embeddings = {}
        for i, name in enumerate(modality_names):
            updated_modality_embeddings[name] = updated_embeddings[:, i, :]
        
        return updated_modality_embeddings
    
    def forward(self, 
                modality_embeddings: Dict[str, torch.Tensor],
                missing_mask: torch.Tensor,
                normalized_adjacency: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Forward pass for modality embeddings update
        
        Args:
            modality_embeddings: Dict mapping modality names to embeddings
                                Each embedding has shape (batch_size, hidden_size)
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
            normalized_adjacency: Normalized adjacency matrix D^{-1/2} A D^{-1/2}
                                Shape: (num_modalities, num_modalities)
        
        Returns:
            Updated modality embeddings z̃_i^m
        """
        # Compute gating weights
        gating_weights = self.compute_gating_weights(missing_mask)
        
        # Apply gated graph propagation
        updated_embeddings = self.apply_gated_graph_propagation(
            modality_embeddings, normalized_adjacency, gating_weights
        )
        
        return updated_embeddings
    
    def get_gating_weights(self, missing_mask: torch.Tensor) -> torch.Tensor:
        """
        Get gating weights for analysis/debugging
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Gating weights γ_{mm'}(r_i)
        """
        return self.compute_gating_weights(missing_mask)
    
    def get_gating_parameters(self) -> Dict[str, torch.Tensor]:
        """
        Get gating parameters for analysis/debugging
        
        Returns:
            Dict containing gating weights and biases
        """
        if not self.use_gating:
            return {}
        
        return {
            'gating_weights': self.gating_weights,
            'gating_biases': self.gating_biases
        }
    
    def set_gating_parameters(self, gating_weights: torch.Tensor, gating_biases: torch.Tensor):
        """
        Set gating parameters
        
        Args:
            gating_weights: Gating weight parameters a_{mm'}
                          Shape: (num_modalities, num_modalities, num_modalities)
            gating_biases: Gating bias parameters b_{mm'}
                         Shape: (num_modalities, num_modalities)
        """
        if not self.use_gating:
            raise ValueError("Gating is disabled. Enable gating to set parameters.")
        
        if gating_weights.shape != (self.num_modalities, self.num_modalities, self.num_modalities):
            raise ValueError(f"Gating weights must have shape ({self.num_modalities}, {self.num_modalities}, {self.num_modalities})")
        
        if gating_biases.shape != (self.num_modalities, self.num_modalities):
            raise ValueError(f"Gating biases must have shape ({self.num_modalities}, {self.num_modalities})")
        
        self.gating_weights.data = gating_weights.clone()
        self.gating_biases.data = gating_biases.clone()
    
    def analyze_gating_behavior(self, missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Analyze gating behavior for different missing patterns
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Dict containing gating analysis
        """
        gating_weights = self.compute_gating_weights(missing_mask)
        
        # Compute statistics
        mean_gating = torch.mean(gating_weights, dim=0)  # Average across batch
        std_gating = torch.std(gating_weights, dim=0)    # Std across batch
        
        # Find strongest and weakest connections
        max_gating, max_indices = torch.max(gating_weights.view(gating_weights.shape[0], -1), dim=1)
        min_gating, min_indices = torch.min(gating_weights.view(gating_weights.shape[0], -1), dim=1)
        
        return {
            'gating_weights': gating_weights,
            'mean_gating': mean_gating,
            'std_gating': std_gating,
            'max_gating': max_gating,
            'min_gating': min_gating,
            'max_indices': max_indices,
            'min_indices': min_indices
        }
