"""
Statistical Embedding Module

This module implements the statistical embedding component of Pattern-Aware Graph:
u_i = MLP([1/max(|O_i|, 1) * sum_{m in O_i} z_i^m; mean(r_i); var(r_i)])

where:
- |O_i| is the number of observed modalities
- mean(r_i) and var(r_i) summarize the proportion and dispersion of missingness patterns
- z_i^m are the modality-specific embeddings
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional


class StatisticalEmbedding(nn.Module):
    """
    Statistical Embedding Module for Pattern-Aware Graph
    
    Aggregates observed semantics and sample-level statistics to create
    a unified representation of missing patterns.
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        self.hidden_size = config["hidden_size"]
        self.num_modalities = config.get("num_modalities", 2)  # text and image by default
        self.embed_dim = config.get("statistical_embed_dim", 128)
        
        # MLP for processing the concatenated features
        # Input: [aggregated_modality_embeddings, mean_missing, var_missing]
        # aggregated_modality_embeddings: hidden_size
        # mean_missing: 1 (scalar)
        # var_missing: 1 (scalar)
        input_dim = self.hidden_size + 2  # +2 for mean and variance
        
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, self.embed_dim * 2),
            nn.LayerNorm(self.embed_dim * 2),
            nn.GELU(),
            nn.Dropout(config.get("drop_rate", 0.1)),
            nn.Linear(self.embed_dim * 2, self.embed_dim),
            nn.LayerNorm(self.embed_dim),
            nn.GELU(),
            nn.Dropout(config.get("drop_rate", 0.1))
        )
        
        # Initialize weights
        self.apply(self._init_weights)
    
    def _init_weights(self, module):
        """Initialize module weights"""
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=0.02)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)
    
    def compute_missing_pattern_stats(self, missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Compute statistics for missing patterns
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M indicating missing modalities
                         Shape: (batch_size, num_modalities)
        
        Returns:
            Dict containing:
                - mean_missing: Proportion of observed modalities (batch_size,)
                - var_missing: Dispersion of missingness patterns (batch_size,)
                - num_observed: Number of observed modalities (batch_size,)
                - observed_sets: List of observed modality indices for each sample
        """
        batch_size, num_modalities = missing_mask.shape
        
        # Convert to float for computation
        mask_float = missing_mask.float()
        
        # Compute statistics
        mean_missing = torch.mean(mask_float, dim=-1)  # Proportion of observed modalities
        var_missing = torch.var(mask_float, dim=-1)    # Dispersion of missingness patterns
        num_observed = torch.sum(missing_mask, dim=-1)  # Number of observed modalities
        
        # Get observed set for each sample
        observed_sets = []
        for i in range(batch_size):
            observed = torch.where(missing_mask[i] == 1)[0].tolist()
            observed_sets.append(observed)
        
        return {
            'mean_missing': mean_missing,
            'var_missing': var_missing,
            'num_observed': num_observed,
            'observed_sets': observed_sets
        }
    
    def aggregate_modality_embeddings(self, 
                                    modality_embeddings: Dict[str, torch.Tensor],
                                    missing_mask: torch.Tensor,
                                    observed_sets: List[List[int]]) -> torch.Tensor:
        """
        Aggregate observed modality embeddings
        
        Args:
            modality_embeddings: Dict mapping modality names to embeddings
                                Each embedding has shape (batch_size, hidden_size)
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
            observed_sets: List of observed modality indices for each sample
        
        Returns:
            Aggregated embeddings: (batch_size, hidden_size)
        """
        batch_size = missing_mask.shape[0]
        device = missing_mask.device
        
        # Convert modality embeddings to list for easier indexing
        modality_list = list(modality_embeddings.values())
        num_modalities = len(modality_list)
        
        # Initialize aggregated embeddings
        aggregated_embeddings = torch.zeros(batch_size, self.hidden_size, device=device)
        
        for i in range(batch_size):
            observed_modalities = observed_sets[i]
            num_observed = len(observed_modalities)
            
            if num_observed > 0:
                # Sum embeddings of observed modalities
                for mod_idx in observed_modalities:
                    if mod_idx < num_modalities:  # Safety check
                        aggregated_embeddings[i] += modality_list[mod_idx][i]
                
                # Average by number of observed modalities
                aggregated_embeddings[i] /= max(num_observed, 1)
            else:
                # If no modalities are observed, use zero vector
                aggregated_embeddings[i] = torch.zeros(self.hidden_size, device=device)
        
        return aggregated_embeddings
    
    def forward(self, 
                modality_embeddings: Dict[str, torch.Tensor],
                missing_mask: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for statistical embedding
        
        Args:
            modality_embeddings: Dict mapping modality names to embeddings
                                Each embedding has shape (batch_size, hidden_size)
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Statistical embedding u_i: (batch_size, embed_dim)
        """
        # Compute missing pattern statistics
        stats = self.compute_missing_pattern_stats(missing_mask)
        
        # Aggregate observed modality embeddings
        aggregated_embeddings = self.aggregate_modality_embeddings(
            modality_embeddings, missing_mask, stats['observed_sets']
        )
        
        # Prepare input features: [aggregated_embeddings, mean_missing, var_missing]
        mean_missing = stats['mean_missing'].unsqueeze(-1)  # (batch_size, 1)
        var_missing = stats['var_missing'].unsqueeze(-1)    # (batch_size, 1)
        
        # Concatenate features
        input_features = torch.cat([
            aggregated_embeddings,  # (batch_size, hidden_size)
            mean_missing,          # (batch_size, 1)
            var_missing            # (batch_size, 1)
        ], dim=-1)  # (batch_size, hidden_size + 2)
        
        # Process through MLP
        statistical_embedding = self.mlp(input_features)  # (batch_size, embed_dim)
        
        return statistical_embedding
    
    def get_embedding_dim(self) -> int:
        """Get the dimension of the statistical embedding"""
        return self.embed_dim


