"""
Cross-Modal Dependencies Module

This module implements the cross-modal dependencies component of Pattern-Aware Graph:
A = A_prior ⊙ A_learned

where:
- A_prior ∈ {0,1}^{M×M} encodes known semantic couplings
- A_learned ∈ R^{M×M} contains learnable weights
- ⊙ denotes element-wise multiplication
- D_{mm} = sum_{m'} A_{mm'} (diagonal degree matrix)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional, Union


class CrossModalDependencies(nn.Module):
    """
    Cross-Modal Dependencies Module for Pattern-Aware Graph
    
    Models inter-modality relations via a graph G=(M,E), with nodes as modalities
    and edges as dependencies. The adjacency matrix combines prior knowledge and
    learnable weights.
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        self.num_modalities = config.get("num_modalities", 2)  # text and image by default
        self.use_prior_knowledge = config.get("use_prior_knowledge", True)
        self.symmetric_adjacency = config.get("symmetric_adjacency", False)
        
        # Initialize prior adjacency matrix A_prior
        if self.use_prior_knowledge:
            self.register_buffer('prior_adjacency', self._create_prior_adjacency())
        else:
            # Fully connected graph if no prior knowledge
            self.register_buffer('prior_adjacency', torch.ones(self.num_modalities, self.num_modalities))
            # Remove self-loops
            self.prior_adjacency.fill_diagonal_(0)
        
        # Learnable weights A_learned
        self.learnable_weights = nn.Parameter(
            torch.randn(self.num_modalities, self.num_modalities) * 0.1
        )
        
        # Initialize learnable weights
        self._init_learnable_weights()
    
    def _create_prior_adjacency(self) -> torch.Tensor:
        """
        Create prior adjacency matrix based on domain knowledge
        
        For vision-language tasks, we typically have:
        - Text and Image modalities
        - They are semantically related (bidirectional)
        
        Returns:
            Prior adjacency matrix A_prior ∈ {0,1}^{M×M}
        """
        if self.num_modalities == 2:
            # For text-image pairs, they are mutually dependent
            prior_adj = torch.ones(2, 2)
            prior_adj.fill_diagonal_(0)  # Remove self-loops
            return prior_adj
        else:
            # For more modalities, create a more sophisticated prior
            # This can be extended based on domain knowledge
            prior_adj = torch.ones(self.num_modalities, self.num_modalities)
            prior_adj.fill_diagonal_(0)  # Remove self-loops
            return prior_adj
    
    def _init_learnable_weights(self):
        """Initialize learnable weights"""
        # Initialize with small random values
        nn.init.normal_(self.learnable_weights, mean=0.0, std=0.1)
        
        # Ensure self-loops are zero
        self.learnable_weights.data.fill_diagonal_(0.0)
    
    def get_adjacency_matrix(self) -> torch.Tensor:
        """
        Compute the combined adjacency matrix A = A_prior ⊙ A_learned
        
        Returns:
            Adjacency matrix A ∈ R^{M×M}
        """
        # Apply sigmoid to learnable weights to ensure they are in (0, 1)
        learned_adjacency = torch.sigmoid(self.learnable_weights)
        
        # Combine with prior knowledge: A = A_prior ⊙ A_learned
        adjacency_matrix = self.prior_adjacency * learned_adjacency
        
        # Ensure self-loops are zero
        adjacency_matrix.fill_diagonal_(0.0)
        
        # Make symmetric if required
        if self.symmetric_adjacency:
            adjacency_matrix = (adjacency_matrix + adjacency_matrix.T) / 2
        
        return adjacency_matrix
    
    def get_degree_matrix(self, adjacency_matrix: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Compute diagonal degree matrix D where D_{mm} = sum_{m'} A_{mm'}
        
        Args:
            adjacency_matrix: Adjacency matrix A. If None, uses current adjacency matrix
        
        Returns:
            Diagonal degree matrix D ∈ R^{M×M}
        """
        if adjacency_matrix is None:
            adjacency_matrix = self.get_adjacency_matrix()
        
        # Compute degree for each node
        degree = torch.sum(adjacency_matrix, dim=-1)  # (num_modalities,)
        
        # Create diagonal matrix
        degree_matrix = torch.diag(degree)
        
        return degree_matrix
    
    def normalize_adjacency_matrix(self, adjacency_matrix: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Normalize adjacency matrix using symmetric normalization: D^{-1/2} A D^{-1/2}
        
        Args:
            adjacency_matrix: Adjacency matrix A. If None, uses current adjacency matrix
        
        Returns:
            Normalized adjacency matrix D^{-1/2} A D^{-1/2} ∈ R^{M×M}
        """
        if adjacency_matrix is None:
            adjacency_matrix = self.get_adjacency_matrix()
        
        # Compute degree matrix
        degree_matrix = self.get_degree_matrix(adjacency_matrix)
        
        # Add small epsilon to avoid division by zero
        epsilon = 1e-8
        degree_sqrt_inv = torch.pow(torch.diag(degree_matrix) + epsilon, -0.5)
        
        # Create diagonal matrix with inverse square root of degrees
        degree_sqrt_inv_matrix = torch.diag(degree_sqrt_inv)
        
        # Symmetric normalization: D^{-1/2} A D^{-1/2}
        normalized_adj = torch.mm(torch.mm(degree_sqrt_inv_matrix, adjacency_matrix), degree_sqrt_inv_matrix)
        
        return normalized_adj
    
    def get_modality_influence_weights(self, missing_mask: torch.Tensor) -> torch.Tensor:
        """
        Compute modality influence weights based on missing patterns
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Influence weights for each modality pair (batch_size, num_modalities, num_modalities)
        """
        batch_size, num_modalities = missing_mask.shape
        device = missing_mask.device
        
        # Get normalized adjacency matrix
        normalized_adj = self.normalize_adjacency_matrix()  # (num_modalities, num_modalities)
        
        # Expand to batch dimension
        influence_weights = normalized_adj.unsqueeze(0).expand(batch_size, -1, -1)  # (batch_size, num_modalities, num_modalities)
        
        # Mask out influences from missing modalities
        # If modality m' is missing, its influence on other modalities should be reduced
        missing_mask_expanded = missing_mask.unsqueeze(-1)  # (batch_size, num_modalities, 1)
        influence_weights = influence_weights * missing_mask_expanded
        
        return influence_weights
    
    def forward(self, missing_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Forward pass for cross-modal dependencies
        
        Args:
            missing_mask: Binary mask r_i ∈ {0,1}^M (batch_size, num_modalities)
        
        Returns:
            Dict containing:
                - adjacency_matrix: Combined adjacency matrix A
                - normalized_adjacency: Normalized adjacency matrix D^{-1/2} A D^{-1/2}
                - degree_matrix: Diagonal degree matrix D
                - influence_weights: Modality influence weights
        """
        # Get adjacency matrix
        adjacency_matrix = self.get_adjacency_matrix()
        
        # Get normalized adjacency matrix
        normalized_adjacency = self.normalize_adjacency_matrix(adjacency_matrix)
        
        # Get degree matrix
        degree_matrix = self.get_degree_matrix(adjacency_matrix)
        
        # Get influence weights based on missing patterns
        influence_weights = self.get_modality_influence_weights(missing_mask)
        
        return {
            'adjacency_matrix': adjacency_matrix,
            'normalized_adjacency': normalized_adjacency,
            'degree_matrix': degree_matrix,
            'influence_weights': influence_weights
        }
    
    def get_prior_adjacency(self) -> torch.Tensor:
        """Get the prior adjacency matrix"""
        return self.prior_adjacency
    
    def get_learnable_weights(self) -> torch.Tensor:
        """Get the learnable weights"""
        return self.learnable_weights
    
    def set_prior_adjacency(self, prior_adjacency: torch.Tensor):
        """
        Set the prior adjacency matrix
        
        Args:
            prior_adjacency: New prior adjacency matrix ∈ {0,1}^{M×M}
        """
        if prior_adjacency.shape != (self.num_modalities, self.num_modalities):
            raise ValueError(f"Prior adjacency matrix must have shape ({self.num_modalities}, {self.num_modalities})")
        
        self.register_buffer('prior_adjacency', prior_adjacency.clone())
    
    def get_graph_info(self) -> Dict[str, Union[torch.Tensor, int]]:
        """
        Get information about the graph structure
        
        Returns:
            Dict containing graph information
        """
        adjacency_matrix = self.get_adjacency_matrix()
        degree_matrix = self.get_degree_matrix(adjacency_matrix)
        
        return {
            'num_modalities': self.num_modalities,
            'num_edges': torch.sum(adjacency_matrix > 0).item(),
            'max_degree': torch.max(torch.diag(degree_matrix)).item(),
            'min_degree': torch.min(torch.diag(degree_matrix)).item(),
            'avg_degree': torch.mean(torch.diag(degree_matrix)).item(),
            'is_connected': self._is_connected(adjacency_matrix)
        }
    
    def _is_connected(self, adjacency_matrix: torch.Tensor) -> bool:
        """
        Check if the graph is connected
        
        Args:
            adjacency_matrix: Adjacency matrix A
        
        Returns:
            True if the graph is connected, False otherwise
        """
        # Simple connectivity check for small graphs
        # For larger graphs, more sophisticated algorithms would be needed
        
        # Make adjacency matrix symmetric for undirected graph
        sym_adj = (adjacency_matrix + adjacency_matrix.T) / 2
        sym_adj = (sym_adj > 0).float()
        
        # Check if all nodes are reachable from node 0
        visited = torch.zeros(self.num_modalities, dtype=torch.bool)
        queue = [0]
        visited[0] = True
        
        while queue:
            current = queue.pop(0)
            for neighbor in range(self.num_modalities):
                if sym_adj[current, neighbor] > 0 and not visited[neighbor]:
                    visited[neighbor] = True
                    queue.append(neighbor)
        
        return torch.all(visited).item()


