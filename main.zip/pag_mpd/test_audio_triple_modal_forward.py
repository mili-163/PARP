#!/usr/bin/env python3
import os
import sys
import torch

ROOT = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(ROOT)
sys.path.insert(0, PKG_ROOT)
from pag_mpd.core import PAGMPDModel


def main():
    torch.manual_seed(7)
    B = 4
    L = 12
    d = 512
    C = 5

    config = {
        'mock_backbone': True,
        'vocab_size': 30522,
        'hidden_size': d,
        'num_layers': 2,
        'num_heads': 8,
        'mlp_ratio': 4,
        'max_text_len': L,
        'drop_rate': 0.0,
        'max_image_len': 10,
        'num_modalities': 3,
        'modality_names': ['text','image','audio'],
        'statistical_embed_dim': 128,
        'num_paths': 4,
        'top_s': 2,
        'gumbel_tau': 1.0,
        'adapter_rank': 32,
        'adapter_cond_dim': 128,
        'prompt_len': 16,
        'prompt_cond_dim': d + 128,
        'prompt_hidden': 512,
        'fusion_heads': 4,
        'contrastive_tau': 0.07,
        'contrastive_proj': 256,
        'num_classes': C,
        'lambda_kd': 0.01,
        'lambda_lap': 0.1,
        'lambda_con': 0.1,
        'lambda_peak': 0.05,
        'lambda_div': 0.05,
        'loss_names': {'hatememes':0,'food101':0,'mmimdb':0},
        'load_path': '',
        'use_audio': True,
    }

    model = PAGMPDModel(config)

    # synthetic batch
    text_ids = torch.randint(0, config['vocab_size'], (B, L))
    text_labels = torch.zeros(B, L, dtype=torch.long)
    text_masks = torch.ones(B, L, dtype=torch.long)
    images = torch.randn(B, 3, 224, 224)
    audio_feats = torch.randn(B, 128)
    missing_type = torch.tensor([[1,1,1],[1,0,1],[0,1,1],[0,0,1]], dtype=torch.long)
    labels = torch.randint(0, C, (B,))

    batch = {
        'text_ids': text_ids,
        'text_labels': text_labels,
        'text_masks': text_masks,
        'image': (images,),
        'audio_feats': audio_feats,
        'missing_type': missing_type,
        'labels': labels,
    }

    out = model.infer(batch)
    print('✓ modalities in bar_z:', list(out['bar_z'].keys()))
    print('✓ fused_feats:', tuple(out['fused_feats'].shape))
    total = sum([v for k,v in out.items() if isinstance(v, torch.Tensor) and 'loss' in k])
    print('✓ total loss:', float(total))


if __name__ == '__main__':
    main()
